<?php
session_start();
//connect to database
include 'connect.php';

//time to update tables, so check for required fields
if (($_POST['f_name'] == "") || ($_POST['l_name'] == "")) {
header("Location: changeEntry.php");
exit;
}

//connect to database
doDB();
//create clean versions of input strings
$master_id=$_SESSION["master_id"];
$safe_f_name = mysqli_real_escape_string($mysqli, $_POST['f_name']);
$safe_l_name = mysqli_real_escape_string($mysqli, $_POST['l_name']);
$safe_albumName = mysqli_real_escape_string($mysqli, $_POST['albumName']);
$safe_yearReleased = mysqli_real_escape_string($mysqli, $_POST['yearReleased']);
$safe_genre = mysqli_real_escape_string($mysqli, $_POST['genre']);
$safe_numberOfTracks = mysqli_real_escape_string($mysqli, $_POST['numberOfTracks']);
$safe_name = mysqli_real_escape_string($mysqli, $_POST['name']);
$safe_country = mysqli_real_escape_string($mysqli, $_POST['country']);

//update master_name table
$add_master_sql = "UPDATE master_name SET date_added=now(),date_modified=now(),f_name='".$safe_f_name."',l_name='". $safe_l_name."' WHERE id='".$master_id."'";
$add_master_res = mysqli_query($mysqli, $add_master_sql) or die(mysqli_error($mysqli));

if ($_SESSION["album"]=="true"){
    //update album table
    $add_albums_sql = "UPDATE album SET master_id='".$master_id."',albumName='".$safe_albumName."',yearReleased='". $safe_yearReleased ."',genre='". $safe_genre . "',numberOfTracks='".$safe_numberOfTracks."' WHERE master_id='".$master_id."'";
    $add_albums_res = mysqli_query($mysqli, $add_albums_sql) or die(mysqli_error($mysqli));
}
else if (($_POST['albumName']) || ($_POST['yearReleased']) || ($_POST['genre']) || ($_POST['numberOfTracks'])) {
    //add new record to table
    $add_albums_sql = "INSERT INTO album (master_id, albumName, yearReleased, genre, numberOfTracks) VALUES ('". $master_id."','".$safe_albumName."', '".$safe_yearReleased."','".$safe_genre."' , '".$safe_numberOfTracks."')";
    $add_albums_res = mysqli_query($mysqli, $add_albums_sql) or die(mysqli_error($mysqli));
}

if ($_SESSION["artist"]=="true"){
    //update artist table
    $add_artists_sql = "UPDATE artist SET master_id='".$master_id."',name='". $safe_name ."',country='" .$safe_country."'WHERE master_id='".$master_id."'";
    $add_artists_res = mysqli_query($mysqli, $add_artists_sql) or die(mysqli_error($mysqli));
}
else if (($_POST['name']) || ($_POST['country'])) {
    //add new record to table
    $add_artists_sql = "INSERT INTO artist (master_id, name, country) VALUES ('". $master_id."','".$safe_name."', '".$safe_country. "')";
    $add_artist_res = mysqli_query($mysqli, $add_artists_sql) or die(mysqli_error($mysqli));
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Update an Album</title>
<link href="greens.css" type="text/css" rel="stylesheet" />
</head>
<body>
<h1>Update an Album</h1>
<?php
$display_block = "<p>Your entry has been changed...Would you like to return to the <a href='addressBookMenu.html'>main menu</a>?...<a href='changeEntry.php'>Change another record?</a></p>"; 
echo $display_block; 
?>
</body>
</html>
