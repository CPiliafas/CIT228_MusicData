<?php
session_start();
include 'connect.php';
doDB();

if (!$_POST) {
//haven't seen the selection form, so show it
$display_block = "<h1>Select an Entry to Update</h1>";

//get parts of records
$get_list_sql = "SELECT id,
CONCAT_WS(', ', l_name, f_name) AS display_name
FROM master_name ORDER BY l_name, f_name";
$get_list_res = mysqli_query($mysqli, $get_list_sql) or die(mysqli_error($mysqli));

if (mysqli_num_rows($get_list_res) < 1) {
//no records
$display_block .= "<p><em>Sorry, no records to select!</em></p>";

} else {
//has records, so get results and print in a form
$display_block .= "
<form method=\"post\" action=\"".$_SERVER['PHP_SELF']."\">
<p><label for=\"change_id\">Select a Record to Update:</label><br/>
<select id=\"change_id\" name=\"change_id\" required=\"required\">
<option value=\"\">-- Select One --</option>";

while ($recs = mysqli_fetch_array($get_list_res)) {
$id = $recs['id'];
$display_name = stripslashes($recs['display_name']);
$display_block .= "<option value=\"".$id."\">".$display_name."</option>";
}

$display_block .= "
</select></p>
<button type=\"submit\" name=\"submit\" value=\"change\">Change Selected Entry</button>
</form>";
}
//free result
mysqli_free_result($get_list_res);

}
else if ($_POST) {
    //check for required fields
    if ($_POST['change_id'] == "") {
    header("Location: changeEntry.php");
    exit;
}

//create safe version of ID
$safe_id = mysqli_real_escape_string($mysqli, $_POST['change_id']);
//create session variables for use in change.php
$_SESSION["master_id"]=$safe_id;
$_SESSION["album"]="true";
$_SESSION["artist"]="true";

//get master_info
$get_master_sql = "SELECT f_name, l_name FROM master_name WHERE id = '".$safe_id."'";
$get_master_res = mysqli_query($mysqli, $get_master_sql) or die(mysqli_error($mysqli));
//clean master_name info
while ($name_info = mysqli_fetch_array($get_master_res)) {
      $display_fname = stripslashes($name_info['f_name']);
       $display_lname = stripslashes($name_info['l_name']); 
}
// display master_name info
$display_block = "<h1>Record Update</h1>";
$display_block.="<form method='post' action='change.php'>";
$display_block.="<fieldset><legend>First/Last Names:</legend><br/>";
$display_block.="<input type='text' name='f_name' size='20' maxlength='75' required='required' value='" . $display_fname . "'/>";
$display_block.="<input type='text' name='l_name' size='30' maxlength='75' required='required' value='" . $display_lname . "'/></fieldset>";

//free result
mysqli_free_result($get_master_res);

//get all albums
$get_albums_sql = "SELECT albumName, yearReleased, genre, numberOfTracks
FROM album WHERE master_id = '".$safe_id."'";
$get_albums_res = mysqli_query($mysqli, $get_albums_sql) or die(mysqli_error($mysqli));
// check to see if album exists
if (mysqli_num_rows($get_albums_res) > 0) {
$display_block .= "<p><strong>Albums:</strong></p>";
while ($add_info = mysqli_fetch_array($get_albums_res)) {
    $albumName = stripslashes($add_info['albumName']);
    $yearReleased = stripslashes($add_info['yearReleased']);
    $genre = stripslashes($add_info['genre']);
    $numberOfTracks = stripslashes($add_info['numberOfTracks']);
    $display_block .="<fieldset><legend>Album Name/Year Released/Genre/Number of Tracks:</legend><br/>";
    $display_block .="<input type='text' name='albumName' size='20' maxlength='30' value='" . $albumName . "'/>";
    $display_block .="<input type='text' name='yearReleased' size='30' maxlength='4' value='" . $yearReleased . "'/>";
    $display_block .="<input type='text' name='genre' size='5' maxlength='15' value='".$genre."'/>";
    $display_block .="<input type='text' name='numberOfTracks' size='10' maxlength='2' value='".$numberOfTracks."'/></fieldset>"; 
    }
$display_block .="</fieldset>";
}  // end of if (mysqli_num_rows($get_albums_res) > 0)

//get all artists
$get_artists_sql = "SELECT name, country
FROM artist WHERE master_id = '".$safe_id."'";
$get_artists_res = mysqli_query($mysqli, $get_artists_sql) or die(mysqli_error($mysqli));
// check to see if artist exists
if (mysqli_num_rows($get_artists_res) > 0) {
$display_block .= "<p><strong>Artists:</strong></p>";
while ($add_info = mysqli_fetch_array($get_artists_res)) {
    $name = stripslashes($add_info['name']);
    $country = stripslashes($add_info['country']);
    $display_block .="<fieldset><legend>Name/Country:</legend><br/>";
    $display_block .="<input type='text' name='name' size='30' maxlength='40' value='" . $name . "'/>";
    $display_block .="<input type='text' name='country' size='5' maxlength='15' value='".$country."'/>";
}

$display_block .="</fieldset>";
}  // end of if (mysqli_num_rows($get_artists_res) > 0)

else{
    //address information was not in the table, turn off session variable and display entry form
    $_SESSION["address"]='false';
    $display_block .= <<<END_OF_BLOCK
    <p><label for="album">Album:</label><br/>
    <input type="text" id="album" name="album" size="30" /></p>

    <fieldset>
    <legend>Year Released/Genre/Number of Tracks:</legend><br/>
    <input type='text' name='yearReleased' size='30' maxlength='4' />
    <input type="text" name="genre" size="5" maxlength="2" />
    <input type="text" name="numberOfTracks" size="10" maxlength="10" />
    </fieldset>
END_OF_BLOCK;
}

//free result
mysqli_free_result($get_albums_res);
mysqli_free_result($get_artists_res);

$display_block .= "<p style=\"text‐align: center\"><button type='submit' name='submitChange'
id='submitChange' value='submitChange'>Change Entry</button>";
$display_block .= "&nbsp;&nbsp;&nbsp;&nbsp;<a href='addressBookMenu.html' style='color:darkgreen';>Cancel
and return to main menu</a></p></form>";
}
//close connection to MySQL
mysqli_close($mysqli);
?>
<!DOCTYPE html>
<html>
<head>
<title>My Records</title>
<link href="greens.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php echo $display_block; ?>
</body>
</html>