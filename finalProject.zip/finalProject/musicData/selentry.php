<?php
include 'connect.php';
doDB();

if (!$_POST)  {
	//haven't seen the selection form, so show it
	$display_block = "<h1>Select an Entry</h1>";

	//get parts of records
	$get_list_sql = "SELECT id,
	                 CONCAT_WS(', ', l_name, f_name) AS display_name
	                 FROM master_name ORDER BY l_name, f_name";
	$get_list_res = mysqli_query($mysqli, $get_list_sql) or die(mysqli_error($mysqli));

	if (mysqli_num_rows($get_list_res) < 1) {
		//no records
		$display_block .= "<p><em>Sorry, no records to select!</em></p>";

	} else {
		//has records, so get results and print in a form
		$display_block .= "
		<form method=\"post\" action=\"".$_SERVER['PHP_SELF']."\">
		<p><label for=\"sel_id\">Select an Album:</label><br/>
		<select id=\"sel_id\" name=\"sel_id\" required=\"required\">
		<option value=\"\">-- Select One --</option>";

		while ($recs = mysqli_fetch_array($get_list_res)) {
			$id = $recs['id'];
			$display_name = stripslashes($recs['display_name']);
			$display_block .= "<option value=\"".$id."\">".$display_name."</option>";
		}

		$display_block .= "
		</select></p>
		<button type=\"submit\" name=\"submit\" value=\"view\">View Selected Entry</button>
		</form>";
	}
	//free result
	mysqli_free_result($get_list_res);

} else if ($_POST) {
	//check for required fields
	if ($_POST['sel_id'] == "")  {
		header("Location: selentry.php");
		exit;
	}

	//create safe version of ID
	$safe_id = mysqli_real_escape_string($mysqli, $_POST['sel_id']);

	//get master_info
	$get_master_sql = "SELECT concat_ws(' ', f_name, l_name) as display_name
	                   FROM master_name WHERE id = '".$safe_id."'";
	$get_master_res = mysqli_query($mysqli, $get_master_sql) or die(mysqli_error($mysqli));

	while ($name_info = mysqli_fetch_array($get_master_res)) {
		$display_name = stripslashes($name_info['display_name']);
	}

	$display_block = "<h1>Showing Record for ".$display_name."</h1>";

	//free result
	mysqli_free_result($get_master_res);

	//get all albums
	$get_albums_sql = "SELECT albumName, yearReleased, genre, numberOfTracks
	                      FROM album WHERE master_id = '".$safe_id."'";
	$get_albums_res = mysqli_query($mysqli, $get_albums_sql) or die(mysqli_error($mysqli));

 	if (mysqli_num_rows($get_albums_res) > 0) {

		$display_block .= "<p><strong>Album (Name, Year of Release, Genre, Number of Tracks):</strong><br/>
		<ul>";

		while ($add_info = mysqli_fetch_array($get_albums_res)) {
			$albumName = stripslashes($add_info['albumName']);
			$yearReleased = stripslashes($add_info['yearReleased']);
			$genre = stripslashes($add_info['genre']);
			$numberOfTracks = stripslashes($add_info['numberOfTracks']);

			$display_block .= "<li>$albumName</li>";
			$display_block .= "<li>$yearReleased</li>";
			$display_block .= "<li>$genre</li>";
			$display_block .= "<li>$numberOfTracks</li>";
		}

		$display_block .= "</ul>";
	}

	//free result
	mysqli_free_result($get_albums_res);

	//get all artists
	$get_artists_sql = "SELECT name, country
	                      FROM artist WHERE master_id = '".$safe_id."'";
	$get_artists_res = mysqli_query($mysqli, $get_artists_sql) or die(mysqli_error($mysqli));

 	if (mysqli_num_rows($get_artists_res) > 0) {

		$display_block .= "<p><strong>Artist Info (Name and Country of Origin):</strong><br/>
		<ul>";

		while ($add_info = mysqli_fetch_array($get_artists_res)) {
			$name = stripslashes($add_info['name']);
			$country = stripslashes($add_info['country']);

			$display_block .= "<li>$name</li>";
			$display_block .= "<li>$country</li>";
		}

		$display_block .= "</ul>";
	}
	//free result
	mysqli_free_result($get_artists_res);

	$display_block .= "<br/>
	<p style=\"text-align: center\"><a href=\"addentry.php?master_id=".$_POST['sel_id']."\">add info</a> ...<a href=\"".$_SERVER['PHP_SELF']."\">select another</a>...<a href='Menu.html'>main menu</a></p>";
}
//close connection to MySQL
mysqli_close($mysqli);
?>
<!DOCTYPE html>
<html>
<head>
<title>My Records</title>
<link href="greens.css" type="text/css" rel="stylesheet" />
</head>
<body>
<?php echo $display_block; ?>
</body>
</html>