<?php
function doDB() {
	global $mysqli;

	//connect to server and select database; you may need it
	$mysqli = mysqli_connect("localhost", "root", "", "music");
	//$mysqli = mysqli_connect("localhost", "lisabalbach_PILIAF1", "CIT190117", "music");
	//lisabalbach_companyDB

	//if connection fails, stop script execution
	if (mysqli_connect_errno()) {
		printf("Connect failed: %s\n", mysqli_connect_error());
		exit();
	}
}
?>