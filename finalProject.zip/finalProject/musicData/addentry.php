<?php
include 'connect.php';

if (!$_POST) {
	//haven't seen the form, so show it
	$display_block = <<<END_OF_BLOCK
	<form method="post" action="$_SERVER[PHP_SELF]">

	<fieldset>
	<legend>First/Last Names:</legend><br/>
	<input type="text" name="f_name" size="30" maxlength="75" required="required" />
	<input type="text" name="l_name" size="30" maxlength="75" required="required" />
	</fieldset>

	<p><label for="album">Album Name:</label><br/>
	<input type="text" id="albumName" name="albumName" size="40" /></p>

	<fieldset>
	<legend>Album Info(Year of release, Genre, Number of tracks):</legend><br/>
	<input type="text" name="yearReleased" size="30" maxlength="4" />
	<input type="text" name="genre" size="5" maxlength="15" />
	<input type="text" name="numberOfTracks" size="10" maxlength="2" />
	</fieldset>

	<fieldset>
	<legend>Artist Info:</legend><br/>
	<input type="text" name="name" size="30" maxlength="40" />
	<input type="text" name="country" size="5" maxlength="15" />
	</fieldset>

	<button type="submit" name="submit" value="send">Add Entry</button>
	</form>
END_OF_BLOCK;

} else if ($_POST) {
	//time to add to tables, so check for required fields
	if (($_POST['f_name'] == "") || ($_POST['l_name'] == "")) {
		header("Location: addentry.php");
		exit;
	}

	//connect to database
	doDB();

	//create clean versions of input strings
	$safe_f_name = mysqli_real_escape_string($mysqli, $_POST['f_name']);
	$safe_l_name = mysqli_real_escape_string($mysqli, $_POST['l_name']);
	$safe_albumName = mysqli_real_escape_string($mysqli, $_POST['albumName']);
	$safe_yearReleased = mysqli_real_escape_string($mysqli, $_POST['yearReleased']);
	$safe_genre = mysqli_real_escape_string($mysqli, $_POST['genre']);
	$safe_numberOfTracks = mysqli_real_escape_string($mysqli, $_POST['numberOfTracks']);
	$safe_name = mysqli_real_escape_string($mysqli, $_POST['name']);
	$safe_country = mysqli_real_escape_string($mysqli, $_POST['country']);

	//add to master_name table
	$add_master_sql = "INSERT INTO master_name (date_added, date_modified, f_name, l_name)
		VALUES (now(), now(), '".$safe_f_name."', '".$safe_l_name."')";
	$add_master_res = mysqli_query($mysqli, $add_master_sql) or die(mysqli_error($mysqli));

	//get master_id for use with other tables
	$master_id = mysqli_insert_id($mysqli);

	if (($_POST['albumName']) || ($_POST['yearReleased']) || ($_POST['genre']) || ($_POST['numberOfTracks'])) {
		//something relevant, so add to album table
		$add_albums_sql = "INSERT INTO album (master_id, albumName, yearReleased, genre, numberOfTracks)  VALUES ('".$master_id."', '".$safe_albumName."', '".$safe_yearReleased."',
		                    '".$safe_genre."' , '".$safe_numberOfTracks."')";
		$add_albums_res = mysqli_query($mysqli, $add_albums_sql) or die(mysqli_error($mysqli));
	}

	if (($_POST['name']) || ($_POST['country'])) {
		//something relevant, so add to artist table
		$add_artists_sql = "INSERT INTO artist (master_id, name, country)  VALUES ('".$master_id."','".$safe_name."', '".$safe_country."')";
		$add_artists_res = mysqli_query($mysqli, $add_artists_sql) or die(mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
	$display_block = "<p>Your entry has been added.  Would you like to <a href=\"addentry.php\">add another</a>?...Would you like to return to the <a href='Menu.html'>main menu</a>?</p>";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Add an Album</title>
<link href="greens.css" type="text/css" rel="stylesheet" />
</head>
<body>
<h1>Add an Album</h1>
<?php echo $display_block; ?>
</body>
</html>